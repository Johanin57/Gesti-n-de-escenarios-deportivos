using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CTorneo
{
    public class DeleteModel : PageModel
    {
        //Un objeto para utilizar los repositorios
        private readonly IRTorneo _repotor;
        //Constructor

        public DeleteModel(IRTorneo repotor)
        {
            this._repotor=repotor;
        }
        //propiedad transportable
        [BindProperty]
        public Torneo Torneo{get;set;}

        public ActionResult OnGet(int id)
        {
            Torneo=_repotor.BuscarTorneo(id);
            if(Torneo!=null)
            {
                ViewData["Mensaje"]="Esta seguro de eliminar el registro?";
                return Page();
            }
                     
            return RedirectToPage("./Index");
        }
        public ActionResult OnPost()
        {
            bool funciono=_repotor.EliminarTorneo(Torneo.Id);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="El torneo no se puede eliminar";
                return Page();
            }
        }
    }
}
