using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CTorneo
{
    public class EditModel : PageModel
    {
        //objeto para utilzar el repositorio
        private readonly IRTorneo _repotor;
        private readonly IRepositorioMunicipio _repomun;
        //constructor
        public EditModel(IRTorneo repotor, IRepositorioMunicipio repomun)
        {
            this._repotor= repotor;
            this._repomun=repomun;
        }
        //Propiedad transportable
        [BindProperty]
        public Torneo Torneo{get;set;}
        public IEnumerable<Municipio>Municipios{get;set;}
        
        public ActionResult OnGet(int id)
        {
            Torneo=_repotor.BuscarTorneo(id);
            if(Torneo!=null)
            {
                Municipios=_repomun.ListarMunicipios();
                return Page();
            }
            else
            {
               return RedirectToPage("./Index");
            }          
        
        }
        public ActionResult OnPost()
        {
            bool funciono=_repotor.ActualizarTorneo(Torneo);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="El torneo ya existe";
                return Page();
            }
        }
    }
}
