using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CTorneo
{
    public class IndexModel : PageModel
    {
        //Crear un objeto para poder utilizar a IRepositorioMunicipio
        private readonly IRTorneo _repotor;
        private readonly IRepositorioMunicipio _repomun;
        //propiedad para el objeto transportado
        [BindProperty]
        public IEnumerable<Torneo> Torneos{get;set;}
        public List<TorneoView> TorneosV= new List<TorneoView>();
        //Constructor de la clase

        public IndexModel(IRTorneo repotor, IRepositorioMunicipio repomun)
        {
            this._repotor=repotor;
            this._repomun=repomun;
        }
        public void OnGet()
        {
            List<Municipio>Municipios=_repomun.ListarMunicipios1();
            Torneos=_repotor.ListarTorneos();
            TorneoView tv=null;
            foreach(var t in Torneos)
            {
                tv=new TorneoView();
                tv.Id=t.Id;
                tv.Nombre=t.Nombre;
                tv.Categoria=t.Categoria;
                tv.FechaFinal=t.FechaFinal;
                tv.FechaInicio=t.FechaInicio;
                foreach(var m in Municipios)
                {
                    if(t.MunicipioId==m.Id)
                    {
                        tv.Municipio=m.Nombre;
                    }
                }
                TorneosV.Add(tv);
            }

        }
    }
}
