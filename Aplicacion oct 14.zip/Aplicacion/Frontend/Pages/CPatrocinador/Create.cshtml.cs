using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CPatrocinador
{
    public class CreateModel : PageModel
    {
        //Crear el objeto para hacer uso de IRepositorioMunicipio
        private readonly IRPatrocinador _repopat;
        //Constructor
        public CreateModel(IRPatrocinador repopat)
        {
            this._repopat=repopat;
        }
        //propiedad transportable
        [BindProperty]
        public Patrocinador Patrocinador{get;set;}

        public ActionResult OnGet()
        {
            return Page();
        }
        public ActionResult OnPost()
        {
            bool funciono=_repopat.CrearPatrocinador(Patrocinador);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="El patrocinador ya existe...";
                return Page();
            }

        }
    }
}
