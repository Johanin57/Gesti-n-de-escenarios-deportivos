using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEquipo
{
    public class DeleteModel : PageModel
    {
        //Un objeto para utilizar los repositorios
        private readonly IREquipo _repoequ;
        private readonly IRPatrocinador _repopat;
        //Constructor

        public DeleteModel(IREquipo repoequ, IRPatrocinador repopat)
        {
            this._repoequ=repoequ;
            this._repopat= repopat;
        }
        //propiedad transportable
        [BindProperty]
        public Equipo Equipo{get;set;}
        public Patrocinador Patrocinador{get;set;}

        public ActionResult OnGet(int id)
        {
            Equipo=_repoequ.BuscarEquipo(id);
            Patrocinador=_repopat.BuscarPatrocinador(Equipo.PatrocinadorId);
            if(Equipo!=null)
            {
                ViewData["Mensaje"]="Esta seguro de eliminar el registro?";
                return Page();
            }
                     
            return RedirectToPage("./Index");
        }
        public ActionResult OnPost()
        {
            bool funciono=_repoequ.EliminarEquipo(Equipo.Id);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="El Equipo no se puede eliminar";
                return Page();
            }
        }
    }
}
