using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEquipo
{
    public class CreateModel : PageModel
    {
        //Crear el objeto para hacer uso de IRepositorioMunicipio
        private readonly IREquipo _repoequ;
        private readonly IRPatrocinador _repopat;
        //Constructor
        public CreateModel(IREquipo repoequ, IRPatrocinador repopat)
        {
            this._repoequ=repoequ;
            this._repopat= repopat;
        }
        //propiedad transportable
        [BindProperty]
        public Equipo Equipo{get;set;}
        public IEnumerable<Patrocinador> Patrocinadores{get;set;}

        public ActionResult OnGet()
        {
            Patrocinadores=_repopat.ListarPatrocinadores();
            return Page();
        }
        public ActionResult OnPost()
        {
            bool funciono=_repoequ.CrearEquipo(Equipo);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                Patrocinadores=_repopat.ListarPatrocinadores();
                ViewData["Error"]="El torneo ya existe...";
                return Page();
                
            }

        }
    }
}
