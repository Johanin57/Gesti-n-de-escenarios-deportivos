using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEquipo
{
    public class IndexModel : PageModel
    {
         //Crear un objeto para poder utilizar a IRepositorioMunicipio
        private readonly IREquipo _repoequ;
        private readonly IRPatrocinador _repopat;
        //propiedad para el objeto transportado
        [BindProperty]
        public IEnumerable<Equipo> Equipos{get;set;}
        public List<EquipoView> EquiposV= new List<EquipoView>();
        //Constructor de la clase

        public IndexModel(IREquipo repoequ, IRPatrocinador repopat)
        {
            this._repoequ=repoequ;
            this._repopat=repopat;
        }
        public void OnGet()
        {
            List<Patrocinador>Patrocinadores=_repopat.ListarPatrocinadores1();
            Equipos=_repoequ.ListarEquipos();
            EquipoView ev=null;
            foreach(var e in Equipos)
            {
                ev=new EquipoView();
                ev.Id=e.Id;
                ev.Nombre=e.Nombre;
                ev.Deporte=e.Deporte;
                ev.FechaCreacion=e.FechaCreacion;
                
                foreach(var p in Patrocinadores)
                {
                    if(e.PatrocinadorId==p.Id)
                    {
                        ev.Patrocinador=p.Nombre;
                    }
                }
                EquiposV.Add(ev);
            }

        }
    }
}
