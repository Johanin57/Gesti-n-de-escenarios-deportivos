using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dominio;
using Persistencia;

namespace Frontend.Pages.CEquipo
{
    public class EditModel : PageModel
    {
        //objeto para utilzar el repositorio
        private readonly IREquipo _repoequ;
        private readonly IRPatrocinador _repopat;
        //constructor
        public EditModel(IREquipo repoequ, IRPatrocinador repopat)
        {
            this._repoequ= repoequ;
            this._repopat=repopat;
        }
        //Propiedad transportable
        [BindProperty]
        public Equipo Equipo{get;set;}
        public IEnumerable<Patrocinador> Patrocinadores{get;set;}
        
        public ActionResult OnGet(int id)
        {
            Equipo=_repoequ.BuscarEquipo(id);
            if(Equipo!=null)
            {
                Patrocinadores=_repopat.ListarPatrocinadores();
                return Page();
            }
            else
            {
               return RedirectToPage("./Index");
            }          
        
        }
        public ActionResult OnPost()
        {
            bool funciono=_repoequ.ActualizarEquipo(Equipo);
            if(funciono)
            {
                return RedirectToPage("./Index");
            }
            else
            {
                ViewData["Error"]="El equipo ya existe";
                return Page();
            }
        }
    }
}
