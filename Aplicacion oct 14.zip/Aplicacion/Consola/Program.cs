﻿// importacion de paquetes
using System;
using Dominio;
using Persistencia;
using System.Collections.Generic;

namespace Consola
{
    class Program
    {
        private static IRepositorioMunicipio _repomunicipio= new RepositorioMunicipio(new Persistencia.AppContext());
        static void Main(string[] args)
        {
            bool f=crearMunicipio();
            if(f)
            {
                Console.WriteLine("Municipio creado con exito");
            }
            else
            {
                Console.WriteLine("se ha presentado una falla en el proceso");
            }
            //*buscarMunicipio();
            /*bool f=eliminarMunicipio();
            if(f)
            {
                Console.WriteLine("Municipio eliminado con exito");
            }
            else
            {
                Console.WriteLine("se ha presentado una falla en el proceso");
            }*/
            /*bool f=modificarMunicipio();
            if(f)
            {
                Console.WriteLine("Municipio eactualizado con exito");
            }
            else
            {
                Console.WriteLine("se ha presentado una falla en el proceso");
            }*/
            listarMunicipios();
        }
        private static bool crearMunicipio()
        {
            var municipio= new Municipio();
            
            Console.WriteLine("Ingrese el nombre del municipio");
            municipio.Nombre=Console.ReadLine();
            bool funciono= _repomunicipio.CrearMunicipio(municipio);
            return funciono;
        }

        private static void buscarMunicipio()
        {
            var municipio=_repomunicipio.BuscarMunicipio(5);
            if(municipio!=null)
            {
                Console.WriteLine(municipio.Id);
                Console.WriteLine(municipio.Nombre);
            }
            else
            {
                 Console.WriteLine("Municipio no registrado");
            }
        }
        private static bool eliminarMunicipio()
        {
            bool funciono=_repomunicipio.EliminarMunicipio(1);
            return funciono;
        }
        private static bool modificarMunicipio()
        {
            var mun= new Municipio
            {
                Id=2,
                Nombre="Medellin"
            };
            bool funciono= _repomunicipio.ActualizarMunicipio(mun);
            return funciono;
        }
        private static void listarMunicipios()
        {
            IEnumerable<Municipio> Municipios= _repomunicipio.ListarMunicipios();
            foreach (var m in Municipios)
            {
                Console.WriteLine(m.Id +" "+m.Nombre);
            }
        }
    }
    
}
