using System;
using System.Collections.Generic;

namespace Dominio
{
    public class TorneoEquipoView
    {
        public int EquipoId{get;set;}
        public int TorneoId{get;set;}
        public string Torneo{get;set;}
        public string Equipo{get;set;}
    }
}
