using System;
using System.Collections.Generic;

namespace Dominio
{
    public class Torneo
    {
        public int Id{get;set;}
        public string Nombre{get;set;}
        public string Categoria{get;set;}
        public DateTime FechaInicio{get;set;}
        public DateTime FechaFinal{get;set;}
        //llave forane para la relacion con Muinicipio
        public int MunicipioId {get;set;}
        //propedad navigacional para la relacion con TorneoEquipo
        public List<TorneoEquipo> TorneoEquipos{get;set;}
    }
}
