using System;
using System.Collections.Generic;

namespace Dominio
{
    public class EquipoView
    {
        public int Id{get;set;}
        public string Nombre{get;set;}
        public string Deporte{get;set;}
        public DateTime FechaCreacion{get;set;}
        public string Patrocinador{get;set;}
       
    }
}
