using System;
using System.Collections.Generic;

namespace Dominio
{
    public class TorneoView
    {
        public int Id{get;set;}
        public string Nombre{get;set;}
        public string Categoria{get;set;}
        public DateTime FechaInicio{get;set;}
        public DateTime FechaFinal{get;set;}
        public string Municipio{get;set;}
       
    }
}