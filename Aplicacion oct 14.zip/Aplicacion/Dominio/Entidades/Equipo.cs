using System;
using System.Collections.Generic;

namespace Dominio
{
    public class Equipo
    {
        public int Id{get;set;}
        public string Nombre{get;set;}
        public string Deporte{get;set;}
        public DateTime FechaCreacion{get;set;}
        //llave foranea para la relacion con Patrocinador
        public int PatrocinadorId{get;set;}
        //propiedad navigacional para la relacion con Deportista
        public List<Deportista> Deportistas{get;set;}
        // propiedad navigacional para la relacion con Entrenador
        public Entrenador Entrenador{get;set;}
        //propedad navigacional para la relacion con TorneoEquipo
        public List<TorneoEquipo> TorneoEquipos{get;set;}
    }
}
