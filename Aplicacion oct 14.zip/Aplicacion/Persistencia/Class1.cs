﻿using System;

namespace Persistencia
{
    public class Class1
    {
    }
}
