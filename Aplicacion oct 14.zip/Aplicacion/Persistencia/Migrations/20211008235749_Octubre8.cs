﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Persistencia.Migrations
{
    public partial class Octubre8 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Torneos_Municipios_MunicipioId",
                table: "Torneos");

            migrationBuilder.DropColumn(
                name: "MuinicipioId",
                table: "Torneos");

            migrationBuilder.AlterColumn<int>(
                name: "MunicipioId",
                table: "Torneos",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Torneos_Municipios_MunicipioId",
                table: "Torneos",
                column: "MunicipioId",
                principalTable: "Municipios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Torneos_Municipios_MunicipioId",
                table: "Torneos");

            migrationBuilder.AlterColumn<int>(
                name: "MunicipioId",
                table: "Torneos",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "MuinicipioId",
                table: "Torneos",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddForeignKey(
                name: "FK_Torneos_Municipios_MunicipioId",
                table: "Torneos",
                column: "MunicipioId",
                principalTable: "Municipios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
