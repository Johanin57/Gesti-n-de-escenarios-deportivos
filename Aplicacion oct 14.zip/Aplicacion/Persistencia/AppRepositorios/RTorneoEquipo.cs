using System.Collections.Generic;
using Dominio;
using System.Linq;
using System;



namespace Persistencia
{
    public class RTorneoEquipo:IRTorneoEquipo
    {
        // Atributos 
        private readonly AppContext _appContext;
        
        //Metodos
        //Constructor por defecto
        public RTorneoEquipo(AppContext appContext)
        {
            _appContext=appContext;
        }

        public bool CrearTorneoEquipo(TorneoEquipo obj)
        {
            bool creado=false;
            bool existe=ValidarNombre(obj);
            if(!existe)
            {
                try
                {
                    _appContext.TorneoEquipos.Add(obj);
                    _appContext.SaveChanges();
                    creado= true;
                    
                }
                catch (System.Exception)
                {
                    return creado;               
                }

            }            
            return creado;
        }
        public TorneoEquipo BuscarTorneoEquipo(int idT, int idE)
        {
            TorneoEquipo obj=_appContext.TorneoEquipos.FirstOrDefault(t=>t.EquipoId==idE
                                                                && t.TorneoId==idT);
            return obj;
        }

        public bool EliminarTorneoEquipo(int idT, int idE)
        {
            bool eliminado=false;
            var torequ= _appContext.TorneoEquipos.FirstOrDefault(t=>t.EquipoId==idE
                                                                && t.TorneoId==idT);
            if(torequ!=null)
            {
                try
                {
                     _appContext.TorneoEquipos.Remove(torequ);
                     _appContext.SaveChanges();
                     eliminado=true;
                }
                catch (System.Exception)
                {
                   return eliminado;
                }
            }
            return eliminado;
        }

        
        public IEnumerable<TorneoEquipo> ListarTorneoEquipos()
        {
            return _appContext.TorneoEquipos;
        }

       
        // metodo que verifica la existencia de un nombre antes de guardarlo
        bool ValidarNombre(TorneoEquipo obj)
        {
            bool existe=false;
            var torequ=_appContext.TorneoEquipos.FirstOrDefault(t=>t.EquipoId==obj.EquipoId
                                                                && t.TorneoId==obj.TorneoId);
            if(torequ!=null)
            {
                existe=true;
            }
            return existe;
        }

    }
}