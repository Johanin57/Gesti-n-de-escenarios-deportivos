using System.Collections.Generic;
using Dominio;
using System.Linq;
using System;


namespace Persistencia
{
    public class RTorneo:IRTorneo
    {
        // Atributos 
        private readonly AppContext _appContext;
        
        //Metodos
        //Constructor por defecto
        public RTorneo(AppContext appContext)
        {
            _appContext=appContext;
        }

        public bool CrearTorneo(Torneo obj)
        {
            bool creado=false;
            bool existe=ValidarNombre(obj);
            if(!existe)
            {
                try
                {
                    _appContext.Torneos.Add(obj);
                    _appContext.SaveChanges();
                    creado= true;
                    
                }
                catch (System.Exception)
                {
                    return creado;               
                }

            }            
            return creado;
        }
        public Torneo BuscarTorneo(int id)
        {
            return _appContext.Torneos.Find(id);
        }

        public bool EliminarTorneo(int id)
        {
            bool eliminado=false;
            var tor=_appContext.Torneos.Find(id);
            if(tor!=null)
            {
                try
                {
                     _appContext.Torneos.Remove(tor);
                     _appContext.SaveChanges();
                     eliminado=true;
                }
                catch (System.Exception)
                {
                   return eliminado;
                }
            }
            return eliminado;
        }

        public bool ActualizarTorneo(Torneo obj)
        {
            bool actualizado= false;
           // bool existe=ValidarIdentificacion(patrocinador);
            //if(!existe)
           // {
                var tor=_appContext.Torneos.Find(obj.Id);
                if(tor!=null)
                {
                    try
                    {
                        tor.Nombre=obj.Nombre;
                        tor.Categoria=obj.Categoria;
                        tor.FechaInicio=obj.FechaInicio;
                        tor.FechaFinal=obj.FechaFinal;
                        tor.MunicipioId=obj.MunicipioId;
                        _appContext.SaveChanges();
                        actualizado=true;
                    }
                    catch (System.Exception)
                    {                       
                         return actualizado;
                    }
                }
           // }            
            return actualizado;
        }
        public IEnumerable<Torneo> ListarTorneos()
        {
            return _appContext.Torneos;
        }

        public List<Torneo> ListarTorneos1()
        {
            return _appContext.Torneos.ToList();
        }
        // metodo que verifica la existencia de un nombre antes de guardarlo
        bool ValidarNombre(Torneo obj)
        {
            bool existe=false;
            var tor=_appContext.Torneos.FirstOrDefault(t=>t.Nombre==obj.Nombre);
            if(tor!=null)
            {
                existe=true;
            }
            return existe;
        }

    }
}