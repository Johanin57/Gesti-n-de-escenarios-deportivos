using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
    public interface IRepositorioMunicipio
    {
        // Firmar los metodos
        bool CrearMunicipio(Municipio municipio);
        Municipio BuscarMunicipio(int idMunicipio);
        bool EliminarMunicipio(int idMunicipio);
        bool ActualizarMunicipio(Municipio municipio);
        IEnumerable<Municipio> ListarMunicipios();
        List<Municipio> ListarMunicipios1();
    }
}