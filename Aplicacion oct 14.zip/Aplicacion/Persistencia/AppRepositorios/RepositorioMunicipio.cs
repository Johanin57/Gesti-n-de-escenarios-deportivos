using System.Collections.Generic;
using Dominio;
using System.Linq;
using System;


namespace Persistencia
{
    public class RepositorioMunicipio:IRepositorioMunicipio
    {
        // Atributos 
        private readonly AppContext _appContext;
        
        //Metodos
        //Constructor por defecto
        public RepositorioMunicipio(AppContext appContext)
        {
            _appContext=appContext;
        }

        bool IRepositorioMunicipio.CrearMunicipio(Municipio municipio)
        {
            bool creado=false;
            bool existe=ValidarNombre(municipio);
            if(!existe)
            {
                try
                {
                    _appContext.Municipios.Add(municipio);
                    _appContext.SaveChanges();
                    creado= true;
                    
                }
                catch (System.Exception)
                {
                    //Console.WriteLine(e.ToString());
                    return creado;               
                }

            }            
            return creado;
        }
        Municipio IRepositorioMunicipio.BuscarMunicipio(int idMunicipio)
        {
            /*var municipio=_appContext.Municipios.Find(idMunicipio);
            return municipio;*/
            return _appContext.Municipios.Find(idMunicipio);
        }
        bool IRepositorioMunicipio.EliminarMunicipio(int idMunicipio)
        {
            bool eliminado=false;
            var municipio=_appContext.Municipios.Find(idMunicipio);
            if(municipio!=null)
            {
                try
                {
                     _appContext.Municipios.Remove(municipio);
                     _appContext.SaveChanges();
                     eliminado=true;
                }
                catch (System.Exception)
                {
                   return eliminado;
                }
            }
            return eliminado;
        }

        bool IRepositorioMunicipio.ActualizarMunicipio(Municipio municipio)
        {
            bool actualizado= false;
            bool existe=ValidarNombre(municipio);
            if(!existe)
            {
                var mun=_appContext.Municipios.Find(municipio.Id);
                if(mun!=null)
                {
                    try
                    {
                        mun.Nombre=municipio.Nombre;
                        _appContext.SaveChanges();
                        actualizado=true;
                    }
                    catch (System.Exception)
                    {
                        
                         return actualizado;
                    }
                }
            }            
            return actualizado;
        }
        IEnumerable<Municipio> IRepositorioMunicipio.ListarMunicipios()
        {
            return _appContext.Municipios;
        }

        List<Municipio> IRepositorioMunicipio.ListarMunicipios1()
        {
            return _appContext.Municipios.ToList();
        }
        // metodo que verifica la existencia de un nombre antes de guardarlo
        bool ValidarNombre(Municipio municipio)
        {
            bool existe=false;
            var mun=_appContext.Municipios.FirstOrDefault(m=>m.Nombre==municipio.Nombre);
            if(mun!=null)
            {
                existe=true;
            }
            return existe;
        }

    }
}