using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
    public interface IRTorneoEquipo
    {
        // Firmar los metodos
        bool CrearTorneoEquipo(TorneoEquipo obj);
        TorneoEquipo BuscarTorneoEquipo(int idT, int idE);
        bool EliminarTorneoEquipo(int idT, int idE);
        IEnumerable<TorneoEquipo> ListarTorneoEquipos();
       
    }
}