using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
    public interface IRTorneo
    {
        // Firmar los metodos
        bool CrearTorneo(Torneo obj);
        Torneo BuscarTorneo(int id);
        bool EliminarTorneo(int id);
        bool ActualizarTorneo(Torneo obj);
        IEnumerable<Torneo> ListarTorneos();
        List<Torneo> ListarTorneos1();
    }
}