using System.Collections.Generic;
using Dominio;

namespace Persistencia
{
    public interface IREquipo
    {
        // Firmar los metodos
        bool CrearEquipo(Equipo obj);
        Equipo BuscarEquipo(int id);
        bool EliminarEquipo(int id);
        bool ActualizarEquipo(Equipo obj);
        IEnumerable<Equipo> ListarEquipos();
        List<Equipo> ListarEquipos1();
    }
}